#include "../s21_matrix.h"

int s21_calc_complements(matrix_t *A, matrix_t *result) {
  if (s21_check_matrix(A)) return INCORRECT_MATRIX;
  if (s21_check_calculation_errors_one(A)) return CALCULATION_ERROR;

  int creation_status = s21_create_matrix(A->rows, A->columns, result);

  matrix_t minor_matrix;

  for (int i = 0; i < A->rows; i++) {
    for (int j = 0; j < A->columns; j++) {
      double determinant = 0;
      if (!s21_minor(A, i, j, &minor_matrix)) {
        s21_determinant(&minor_matrix, &determinant);
        result->matrix[i][j] = determinant * ((i + j) % 2 == 0 ? 1 : -1);
      }

      s21_remove_matrix(&minor_matrix);
    }
  }

  return creation_status;
}