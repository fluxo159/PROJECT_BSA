#include "../s21_matrix.h"

int s21_determinant(matrix_t *A, double *result) {
  if (s21_check_matrix(A)) return INCORRECT_MATRIX;
  if (s21_check_calculation_errors_one(A)) return CALCULATION_ERROR;

  if (A->rows == 2 && A->columns == 2) {
    *result = (A->matrix[0][0] * A->matrix[1][1]) -
              (A->matrix[0][1] * A->matrix[1][0]);

    return OK;
  }

  if (A->rows == 1 && A->columns == 1) {
    *result = A->matrix[0][0];

    return OK;
  }

  matrix_t minor;
  double determinant = 0;
  for (int i = 0; i < A->columns; i++) {
    if (!s21_minor(A, 0, i, &minor)) {
      double minor_determinant = 0;
      s21_determinant(&minor, &minor_determinant);
      determinant +=
          (A->matrix[0][i] * minor_determinant) * (i % 2 == 0 ? 1 : -1);
    }
    s21_remove_matrix(&minor);
  }

  *result = determinant;
  return OK;
}