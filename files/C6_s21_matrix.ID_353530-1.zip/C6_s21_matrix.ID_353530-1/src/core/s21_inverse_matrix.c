#include "../s21_matrix.h"

int s21_inverse_matrix(matrix_t *A, matrix_t *result) {
  if (s21_check_matrix(A)) return INCORRECT_MATRIX;
  if (s21_check_calculation_errors_one(A)) return CALCULATION_ERROR;

  double determinant = 0;
  matrix_t transposed_matrix;
  matrix_t calc_complements_copy;

  int determinant_status = s21_determinant(A, &determinant);
  if (determinant_status) return determinant_status;
  if (determinant == 0) return CALCULATION_ERROR;

  int transpose_status = s21_transpose(A, &transposed_matrix);
  if (transpose_status) return transpose_status;

  int calc_complements_status =
      s21_calc_complements(&transposed_matrix, &calc_complements_copy);
  if (calc_complements_status) return calc_complements_status;

  double reversed_determinant = 0;

  reversed_determinant = 1 / determinant;

  int result_status =
      s21_mult_number(&calc_complements_copy, reversed_determinant, result);
  if (result_status) return result_status;

  s21_remove_matrix(&transposed_matrix);
  s21_remove_matrix(&calc_complements_copy);

  return OK;
}