#include "../s21_matrix.h"

int s21_check_matrix(matrix_t *A) {
  if (A == NULL) {
    return INCORRECT_MATRIX;
  }
  if (A->rows <= 0 || A->columns <= 0) return INCORRECT_MATRIX;

  return OK;
}

int s21_check_calculation_errors(matrix_t *A, matrix_t *B) {
  if (A == NULL || B == NULL) return INCORRECT_MATRIX;
  if (A->rows != B->rows || A->columns != B->columns) return CALCULATION_ERROR;

  return OK;
}

int s21_check_calculation_errors_one(matrix_t *A) {
  if (A == NULL) return INCORRECT_MATRIX;
  if (A->rows != A->columns) return CALCULATION_ERROR;

  return OK;
}

int s21_is_one(matrix_t *A) {
  if (A == NULL) return 0;
  if (A->rows == 1 && A->columns == 1) return 1;

  return 0;
}

int s21_minor(matrix_t *A, int row_to_ignore, int column_to_ignore,
              matrix_t *result) {
  int creation_status = 0;
  if (s21_is_one(A)) {
    creation_status = s21_create_matrix(A->rows, A->columns, result);

    result->matrix[0][0] = 1;
  } else {
    creation_status = s21_create_matrix(A->rows - 1, A->columns - 1, result);
    int new_matrix_rows = 0;
    int new_matrix_columns = 0;

    for (int i = 0; i < A->rows; i++) {
      if (i != row_to_ignore) {
        new_matrix_columns = 0;
        for (int j = 0; j < A->columns; j++) {
          if (j != column_to_ignore) {
            result->matrix[new_matrix_rows][new_matrix_columns] =
                A->matrix[i][j];
            new_matrix_columns++;
          }
        }
        new_matrix_rows++;
      }
    }
  }

  return creation_status;
}