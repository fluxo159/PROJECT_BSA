#include "../s21_matrix_test.h"

START_TEST(invalid_matrices) {
  matrix_t matrix;
  double number;

  matrix.rows = -1;
  matrix.columns = 100;

  int determinant_status = s21_determinant(&matrix, &number);

  ck_assert_int_eq(determinant_status, INCORRECT_MATRIX);
}
END_TEST

START_TEST(matrix_2_x_2) {
  matrix_t matrix;
  double number;

  int creation_status = s21_create_matrix(3, 3, &matrix);

  for (int i = 0; i < matrix.rows; i++) {
    for (int j = 0; j < matrix.columns; j++) {
      matrix.matrix[i][j] = j + 3;
    }
  }

  int determinant_status = s21_determinant(&matrix, &number);

  ck_assert_int_eq(creation_status, OK);
  ck_assert_int_eq(determinant_status, OK);

  s21_remove_matrix(&matrix);
}
END_TEST

START_TEST(matrix_1_x_1) {
  matrix_t matrix;
  double number;

  int creation_status = s21_create_matrix(1, 1, &matrix);

  for (int i = 0; i < matrix.rows; i++) {
    for (int j = 0; j < matrix.columns; j++) {
      matrix.matrix[i][j] = j + 3;
    }
  }

  int determinant_status = s21_determinant(&matrix, &number);

  ck_assert_int_eq(creation_status, OK);
  ck_assert_int_eq(determinant_status, OK);

  s21_remove_matrix(&matrix);
}
END_TEST

START_TEST(matrix_of_any_size) {
  matrix_t matrix;
  double number;

  int creation_status = s21_create_matrix(4, 4, &matrix);

  for (int i = 0; i < matrix.rows; i++) {
    for (int j = 0; j < matrix.columns; j++) {
      matrix.matrix[i][j] = j + 3;
    }
  }

  int determinant_status = s21_determinant(&matrix, &number);

  ck_assert_int_eq(creation_status, OK);
  ck_assert_int_eq(determinant_status, OK);

  s21_remove_matrix(&matrix);
}
END_TEST

Suite *s21_determinant_tests() {
  Suite *s = suite_create("s21_determinant_tests");
  TCase *tc_core = tcase_create("Core");

  tcase_add_test(tc_core, invalid_matrices);
  tcase_add_test(tc_core, matrix_2_x_2);
  tcase_add_test(tc_core, matrix_1_x_1);
  tcase_add_test(tc_core, matrix_of_any_size);

  suite_add_tcase(s, tc_core);

  return s;
}