#include "../s21_matrix_test.h"

START_TEST(invalid_matrices) {
  matrix_t matrix_1;
  double number = 123;
  matrix_t result;

  matrix_1.rows = -1;
  matrix_1.columns = 0;

  int mult_status = s21_mult_number(&matrix_1, number, &result);

  ck_assert_int_eq(mult_status, INCORRECT_MATRIX);
}
END_TEST

START_TEST(right_value) {
  matrix_t matrix;
  double number = 123;
  matrix_t result;

  int creation_status_1 = s21_create_matrix(3, 3, &matrix);

  for (int i = 0; i < matrix.rows; i++) {
    for (int j = 0; j < matrix.columns; j++) {
      matrix.matrix[i][j] = j + 3;
    }
  }

  int mult_status = s21_mult_number(&matrix, number, &result);

  ck_assert_int_eq(creation_status_1, OK);
  ck_assert_int_eq(mult_status, OK);

  s21_remove_matrix(&matrix);
  s21_remove_matrix(&result);
}
END_TEST

Suite *s21_mult_number_tests() {
  Suite *s = suite_create("s21_mult_numbers_tests");
  TCase *tc_core = tcase_create("Core");

  tcase_add_test(tc_core, invalid_matrices);
  tcase_add_test(tc_core, right_value);

  suite_add_tcase(s, tc_core);

  return s;
}