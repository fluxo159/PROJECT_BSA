#include "../s21_matrix_test.h"

START_TEST(valid_removal) {
  matrix_t matrix;
  int creation_status = s21_create_matrix(3, 3, &matrix);
  s21_remove_matrix(&matrix);

  ck_assert_int_eq(creation_status, 0);
  ck_assert_ptr_null(matrix.matrix);
  ck_assert_int_eq(matrix.rows, 0);
  ck_assert_int_eq(matrix.columns, 0);
}
END_TEST

Suite *s21_remove_matrix_tests() {
  Suite *s;
  TCase *tc_core;

  s = suite_create("s21_remove_matrix_tests");
  tc_core = tcase_create("Core");

  tcase_add_test(tc_core, valid_removal);

  suite_add_tcase(s, tc_core);

  return s;
}