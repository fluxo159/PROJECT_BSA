#include "../s21_matrix_test.h"

int main() {
  int failed = 0;
  Suite *s;
  SRunner *sr;

  s = suite_create("s21_functions_runner");
  sr = srunner_create(s);

  srunner_add_suite(sr, s21_create_matrix_tests());
  srunner_add_suite(sr, s21_remove_matrix_tests());
  srunner_add_suite(sr, s21_eq_matrix_tests());
  srunner_add_suite(sr, s21_sum_matrix_tests());
  srunner_add_suite(sr, s21_sub_matrix_tests());
  srunner_add_suite(sr, s21_mult_number_tests());
  srunner_add_suite(sr, s21_mult_matrix_tests());
  srunner_add_suite(sr, s21_transpose_tests());
  srunner_add_suite(sr, s21_calc_complements_tests());
  srunner_add_suite(sr, s21_determinant_tests());
  srunner_add_suite(sr, s21_inverse_matrix_tests());
  srunner_add_suite(sr, s21_additional_functions_tests());

  srunner_run_all(sr, CK_NORMAL);
  failed = srunner_ntests_failed(sr);

  srunner_free(sr);

  return failed == 0 ? 0 : 1;
}