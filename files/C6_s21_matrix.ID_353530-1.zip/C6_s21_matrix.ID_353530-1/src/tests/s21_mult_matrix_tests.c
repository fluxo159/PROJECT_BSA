#include "../s21_matrix_test.h"

START_TEST(invalid_matrices) {
  matrix_t matrix_1;
  matrix_t matrix_2;
  matrix_t result;

  matrix_1.rows = -1;
  matrix_1.columns = 0;

  int mult_status = s21_mult_matrix(&matrix_1, &matrix_2, &result);

  ck_assert_int_eq(mult_status, INCORRECT_MATRIX);
}
END_TEST

START_TEST(calc_error) {
  matrix_t matrix_1;
  matrix_t matrix_2;
  matrix_t result;

  int creation_status_1 = s21_create_matrix(1, 2, &matrix_1);
  int creation_status_2 = s21_create_matrix(3, 4, &matrix_2);

  int mult_status = s21_mult_matrix(&matrix_1, &matrix_2, &result);

  ck_assert_int_eq(creation_status_1, OK);
  ck_assert_int_eq(creation_status_2, OK);
  ck_assert_int_eq(mult_status, CALCULATION_ERROR);

  s21_remove_matrix(&matrix_1);
  s21_remove_matrix(&matrix_2);
}
END_TEST

START_TEST(right_values) {
  matrix_t matrix_1;
  matrix_t matrix_2;
  matrix_t result;

  int creation_status_1 = s21_create_matrix(3, 4, &matrix_1);
  int creation_status_2 = s21_create_matrix(4, 3, &matrix_2);

  for (int i = 0; i < matrix_1.rows; i++) {
    for (int j = 0; j < matrix_1.columns; j++) {
      matrix_1.matrix[i][j] = j + 3;
    }
  }

  for (int i = 0; i < matrix_2.rows; i++) {
    for (int j = 0; j < matrix_2.columns; j++) {
      matrix_2.matrix[i][j] = j + 3;
    }
  }

  int mult_status = s21_mult_matrix(&matrix_1, &matrix_2, &result);

  ck_assert_int_eq(creation_status_1, OK);
  ck_assert_int_eq(creation_status_2, OK);
  ck_assert_int_eq(mult_status, OK);

  s21_remove_matrix(&matrix_1);
  s21_remove_matrix(&matrix_2);
  s21_remove_matrix(&result);
}
END_TEST

Suite *s21_mult_matrix_tests() {
  Suite *s = suite_create("s21_mult_matrix_tests");
  TCase *tc_core = tcase_create("Core");

  tcase_add_test(tc_core, invalid_matrices);
  tcase_add_test(tc_core, calc_error);
  tcase_add_test(tc_core, right_values);

  suite_add_tcase(s, tc_core);

  return s;
}