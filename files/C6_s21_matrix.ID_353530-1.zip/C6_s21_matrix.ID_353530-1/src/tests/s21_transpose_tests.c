#include "../s21_matrix_test.h"

START_TEST(invalid_matrices) {
  matrix_t matrix;
  matrix_t result;

  matrix.rows = -1;
  matrix.columns = 100;

  int transpose_status = s21_transpose(&matrix, &result);

  ck_assert_int_eq(transpose_status, INCORRECT_MATRIX);
}
END_TEST

START_TEST(right_values) {
  matrix_t matrix;
  matrix_t result;

  int creation_status = s21_create_matrix(3, 3, &matrix);

  for (int i = 0; i < matrix.rows; i++) {
    for (int j = 0; j < matrix.columns; j++) {
      matrix.matrix[i][j] = j + 1;
    }
  }

  int transpose_status = s21_transpose(&matrix, &result);

  ck_assert_int_eq(creation_status, OK);
  ck_assert_int_eq(transpose_status, OK);

  s21_remove_matrix(&matrix);
  s21_remove_matrix(&result);
}
END_TEST

Suite *s21_transpose_tests() {
  Suite *s = suite_create("s21_transpose_tests");
  TCase *tc_core = tcase_create("Core");

  tcase_add_test(tc_core, invalid_matrices);
  tcase_add_test(tc_core, right_values);

  suite_add_tcase(s, tc_core);

  return s;
}