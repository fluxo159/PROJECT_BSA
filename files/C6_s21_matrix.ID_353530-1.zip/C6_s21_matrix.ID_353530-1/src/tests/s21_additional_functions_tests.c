#include "../s21_matrix_test.h"

// check_matrix

START_TEST(check_matrix_error) {
  matrix_t matrix;

  matrix.rows = -1;
  matrix.columns = 100;

  int check_status = s21_check_matrix(&matrix);

  ck_assert_int_eq(check_status, INCORRECT_MATRIX);
}
END_TEST

START_TEST(check_matrix_successful) {
  matrix_t matrix;

  int creations_status = s21_create_matrix(3, 3, &matrix);

  int check_status = s21_check_matrix(&matrix);

  ck_assert_int_eq(creations_status, OK);
  ck_assert_int_eq(check_status, OK);

  s21_remove_matrix(&matrix);
}
END_TEST

// s21_check_calculation_errors

START_TEST(check_calc_error_two_matrices_incorrect_sizes) {
  matrix_t matrix_1;
  matrix_t matrix_2;

  matrix_1.rows = 3;
  matrix_1.columns = 4;

  matrix_2.rows = 5;
  matrix_2.columns = 6;

  int check_status = s21_check_calculation_errors(&matrix_1, &matrix_2);

  ck_assert_int_eq(check_status, CALCULATION_ERROR);
}
END_TEST

START_TEST(check_calc_two_matrices_successful) {
  matrix_t matrix_1;
  matrix_t matrix_2;

  matrix_1.rows = 3;
  matrix_1.columns = 3;

  matrix_2.rows = 3;
  matrix_2.columns = 3;

  int check_status = s21_check_calculation_errors(&matrix_1, &matrix_2);

  ck_assert_int_eq(check_status, OK);
}
END_TEST

// s21_check_calculation_errors_one

START_TEST(check_calculation_errors_one_incorrect_sizes) {
  matrix_t matrix;

  matrix.rows = 3;
  matrix.columns = 4;

  int check_status = s21_check_calculation_errors_one(&matrix);

  ck_assert_int_eq(check_status, CALCULATION_ERROR);
}
END_TEST

START_TEST(check_calculation_errors_one_successful) {
  matrix_t matrix;

  matrix.rows = 4;
  matrix.columns = 4;

  int check_status = s21_check_calculation_errors_one(&matrix);

  ck_assert_int_eq(check_status, OK);
}
END_TEST

// is_one

START_TEST(is_one_incorrect) {
  matrix_t matrix;

  int creation_status = s21_create_matrix(3, 3, &matrix);

  int is_one_status = s21_is_one(&matrix);

  ck_assert_int_eq(creation_status, OK);
  ck_assert_int_eq(is_one_status, 0);

  s21_remove_matrix(&matrix);
}
END_TEST

START_TEST(is_one_successful) {
  matrix_t matrix;

  int creation_status = s21_create_matrix(1, 1, &matrix);

  int is_one_status = s21_is_one(&matrix);

  ck_assert_int_eq(creation_status, OK);
  ck_assert_int_eq(is_one_status, 1);

  s21_remove_matrix(&matrix);
}
END_TEST

// minor

START_TEST(minor_1_x_1_matrix) {
  matrix_t matrix;
  matrix_t result;

  int creation_status = s21_create_matrix(1, 1, &matrix);

  matrix.matrix[0][0] = 0;

  int minor_status = s21_minor(&matrix, 0, 0, &result);

  ck_assert_int_eq(creation_status, OK);
  ck_assert_int_eq(minor_status, OK);

  s21_remove_matrix(&matrix);
  s21_remove_matrix(&result);
}
END_TEST

START_TEST(minor_5_x_5_matrix) {
  matrix_t matrix;
  matrix_t result;

  int creation_status = s21_create_matrix(5, 5, &matrix);

  for (int i = 0; i < matrix.rows; i++) {
    for (int j = 0; j < matrix.columns; j++) {
      matrix.matrix[i][j] = j + 1;
    }
  }

  int minor_status = s21_minor(&matrix, 1, 1, &result);

  ck_assert_int_eq(creation_status, OK);
  ck_assert_int_eq(minor_status, OK);

  s21_remove_matrix(&matrix);
  s21_remove_matrix(&result);
}
END_TEST

Suite *s21_additional_functions_tests() {
  Suite *s = suite_create("s21_additional_functions_tests");
  TCase *tc_core = tcase_create("Core");

  // check_matrix
  tcase_add_test(tc_core, check_matrix_error);
  tcase_add_test(tc_core, check_matrix_successful);

  // check_calculation_errors
  tcase_add_test(tc_core, check_calc_error_two_matrices_incorrect_sizes);
  tcase_add_test(tc_core, check_calc_two_matrices_successful);

  // check_calculation_errors_one
  tcase_add_test(tc_core, check_calculation_errors_one_incorrect_sizes);
  tcase_add_test(tc_core, check_calculation_errors_one_successful);

  // is_one
  tcase_add_test(tc_core, is_one_incorrect);
  tcase_add_test(tc_core, is_one_successful);

  // minor
  tcase_add_test(tc_core, minor_1_x_1_matrix);
  tcase_add_test(tc_core, minor_5_x_5_matrix);

  suite_add_tcase(s, tc_core);

  return s;
}