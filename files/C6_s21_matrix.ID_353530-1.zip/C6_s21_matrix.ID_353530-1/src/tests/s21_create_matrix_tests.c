#include "../s21_matrix_test.h"

START_TEST(incorrect_size) {
  matrix_t matrix;

  int creation_status = s21_create_matrix(0, 0, &matrix);

  ck_assert_int_eq(creation_status, INCORRECT_MATRIX);
}
END_TEST

START_TEST(right_matrix) {
  matrix_t matrix;

  int creation_status = s21_create_matrix(3, 3, &matrix);

  s21_remove_matrix(&matrix);

  ck_assert_int_eq(creation_status, OK);
}
END_TEST

START_TEST(null_matrix) {
  int creation_status = s21_create_matrix(3, 3, NULL);

  ck_assert_int_eq(creation_status, INCORRECT_MATRIX);
}

END_TEST

Suite *s21_create_matrix_tests() {
  Suite *s = suite_create("s21_create_matrix_tests");
  TCase *tc_core = tcase_create("Core");

  tcase_add_test(tc_core, incorrect_size);
  tcase_add_test(tc_core, right_matrix);
  tcase_add_test(tc_core, null_matrix);
  suite_add_tcase(s, tc_core);

  return s;
}