#include "../s21_matrix_test.h"

START_TEST(invalid_matrices) {
  matrix_t matrix_1;
  matrix_t matrix_2;

  matrix_1.rows = -1;
  matrix_1.columns = 0;

  int comparison_status = s21_eq_matrix(&matrix_1, &matrix_2);

  ck_assert_int_eq(comparison_status, FAILURE);
}
END_TEST

START_TEST(equal_matrices) {
  matrix_t matrix_1;
  matrix_t matrix_2;

  int creation_status_1 = s21_create_matrix(3, 3, &matrix_1);
  int creation_status_2 = s21_create_matrix(3, 3, &matrix_2);

  for (int i = 0; i < matrix_1.rows; i++) {
    for (int j = 0; j < matrix_1.columns; j++) {
      matrix_1.matrix[i][j] = j + 1;
      matrix_2.matrix[i][j] = j + 1;
    }
  }

  int comparison_status = s21_eq_matrix(&matrix_1, &matrix_2);

  ck_assert_int_eq(creation_status_1, OK);
  ck_assert_int_eq(creation_status_2, OK);
  ck_assert_int_eq(comparison_status, SUCCESS);

  s21_remove_matrix(&matrix_1);
  s21_remove_matrix(&matrix_2);
}
END_TEST

START_TEST(not_equal_matrices) {
  matrix_t matrix_1;
  matrix_t matrix_2;

  int creation_status_1 = s21_create_matrix(3, 3, &matrix_1);
  int creation_status_2 = s21_create_matrix(3, 3, &matrix_2);

  for (int i = 0; i < matrix_1.rows; i++) {
    for (int j = 0; j < matrix_1.columns; j++) {
      matrix_1.matrix[i][j] = j + 1;
      matrix_2.matrix[i][j] = j + 2;
    }
  }

  int comparison_status = s21_eq_matrix(&matrix_1, &matrix_2);

  ck_assert_int_eq(creation_status_1, OK);
  ck_assert_int_eq(creation_status_2, OK);
  ck_assert_int_eq(comparison_status, FAILURE);

  s21_remove_matrix(&matrix_1);
  s21_remove_matrix(&matrix_2);
}
END_TEST

Suite *s21_eq_matrix_tests() {
  Suite *s = suite_create("s21_eq_matrix_tests");
  TCase *tc_core = tcase_create("Core");

  tcase_add_test(tc_core, invalid_matrices);
  tcase_add_test(tc_core, equal_matrices);
  tcase_add_test(tc_core, not_equal_matrices);

  suite_add_tcase(s, tc_core);

  return s;
}
