#include "../s21_matrix_test.h"

START_TEST(invalid_matrices) {
  matrix_t matrix_1;
  matrix_t matrix_2;
  matrix_t result;

  matrix_1.rows = -1;
  matrix_1.columns = 0;

  int sum_status = s21_sum_matrix(&matrix_1, &matrix_2, &result);

  ck_assert_int_eq(sum_status, INCORRECT_MATRIX);
}
END_TEST

START_TEST(different_sizes) {
  matrix_t matrix_1;
  matrix_t matrix_2;
  matrix_t result;

  int creation_status_1 = s21_create_matrix(3, 3, &matrix_1);
  int creation_status_2 = s21_create_matrix(3, 4, &matrix_2);

  int sum_status = s21_sum_matrix(&matrix_1, &matrix_2, &result);

  ck_assert_int_eq(creation_status_1, OK);
  ck_assert_int_eq(creation_status_2, OK);
  ck_assert_int_eq(sum_status, CALCULATION_ERROR);

  s21_remove_matrix(&matrix_1);
  s21_remove_matrix(&matrix_2);
}
END_TEST

START_TEST(right_values) {
  matrix_t matrix_1;
  matrix_t matrix_2;
  matrix_t result;

  int creation_status_1 = s21_create_matrix(3, 3, &matrix_1);
  int creation_status_2 = s21_create_matrix(3, 3, &matrix_2);

  for (int i = 0; i < matrix_1.rows; i++) {
    for (int j = 0; j < matrix_1.columns; j++) {
      matrix_1.matrix[i][j] = j + 1;
      matrix_2.matrix[i][j] = j + 1;
    }
  }

  int sum_status = s21_sum_matrix(&matrix_1, &matrix_2, &result);

  ck_assert_int_eq(creation_status_1, OK);
  ck_assert_int_eq(creation_status_2, OK);
  ck_assert_int_eq(sum_status, OK);

  s21_remove_matrix(&matrix_1);
  s21_remove_matrix(&matrix_2);
  s21_remove_matrix(&result);
}
END_TEST

Suite *s21_sum_matrix_tests() {
  Suite *s = suite_create("s21_sum_matrix_tests");
  TCase *tc_core = tcase_create("Core");

  tcase_add_test(tc_core, invalid_matrices);
  tcase_add_test(tc_core, different_sizes);
  tcase_add_test(tc_core, right_values);

  suite_add_tcase(s, tc_core);

  return s;
}