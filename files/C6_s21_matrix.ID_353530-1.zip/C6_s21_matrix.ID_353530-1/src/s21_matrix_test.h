#include <check.h>

#include "./s21_matrix.h"

Suite *s21_create_matrix_tests(void);
Suite *s21_remove_matrix_tests(void);
Suite *s21_eq_matrix_tests(void);
Suite *s21_sum_matrix_tests(void);
Suite *s21_sub_matrix_tests(void);
Suite *s21_mult_number_tests(void);
Suite *s21_mult_matrix_tests(void);
Suite *s21_transpose_tests(void);
Suite *s21_calc_complements_tests(void);
Suite *s21_determinant_tests(void);
Suite *s21_inverse_matrix_tests(void);
Suite *s21_additional_functions_tests(void);