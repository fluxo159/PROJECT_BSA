#include "s21_string.h"

int s21_sscanf(const char *src, const char *pattern, ...) {
  va_list ap;
  va_start(ap, pattern);

  int matched = 0;
  const char *ptr = src;
  const char *begin = src;
  const char *pfmt = pattern;

  while (*pfmt) {
    if (*pfmt == '%') {
      pfmt++;
      int skip = 0;
      if (*pfmt == '*') {
        skip = 1;
        pfmt++;
      }
      void *place = skip ? NULL : va_arg(ap, void *);

      switch (*pfmt) {
        case 'd': {
          char *stop;
          int num = (int)strtol(ptr, &stop, 10);
          if (stop != ptr) {
            if (!skip && place) *(int *)place = num;
            ptr = stop;
            if (!skip) matched++;
          } else {
            va_end(ap);
            return matched;
          }
          break;
        }
        case 'u': {
          char *stop;
          unsigned int unum = (unsigned int)strtoul(ptr, &stop, 10);
          if (stop != ptr) {
            if (!skip && place) *(unsigned int *)place = unum;
            ptr = stop;
            if (!skip) matched++;
          } else {
            va_end(ap);
            return matched;
          }
          break;
        }
        case 'x': {
          char *stop;
          unsigned int hexval = (unsigned int)strtoul(ptr, &stop, 16);
          if (stop != ptr) {
            if (!skip && place) *(unsigned int *)place = hexval;
            ptr = stop;
            if (!skip) matched++;
          } else {
            va_end(ap);
            return matched;
          }
          break;
        }
        case 'o': {
          char *stop;
          unsigned int oval = (unsigned int)strtoul(ptr, &stop, 8);
          if (stop != ptr) {
            if (!skip && place) *(unsigned int *)place = oval;
            ptr = stop;
            if (!skip) matched++;
          } else {
            va_end(ap);
            return matched;
          }
          break;
        }
        case 'f': {
          char *stop;
          float fnum = strtof(ptr, &stop);
          if (stop != ptr) {
            if (!skip && place) *(float *)place = fnum;
            ptr = stop;
            if (!skip) matched++;
          } else {
            va_end(ap);
            return matched;
          }
          break;
        }
        case 's': {
          while (*ptr == ' ') ptr++;
          const char *word_start = ptr;
          while (*ptr && !isspace((unsigned char)*ptr)) ptr++;
          if (ptr != word_start) {
            if (!skip && place) {
              char *out = (char *)place;
              while (word_start < ptr) *out++ = *word_start++;
              *out = '\0';
            }
            if (!skip) matched++;
          } else {
            va_end(ap);
            return matched;
          }
          break;
        }
        case 'p': {
          char *stop;
          uintptr_t pval = (uintptr_t)strtoull(ptr, &stop, 16);
          if (stop != ptr) {
            if (!skip && place) *(void **)place = (void *)pval;
            ptr = stop;
            if (!skip) matched++;
          } else {
            va_end(ap);
            return matched;
          }
          break;
        }
        case 'n': {
          if (!skip && place) *(int *)place = (int)(ptr - begin);
          break;
        }
        default:
          va_end(ap);
          return matched;
      }
      pfmt++;
    } else {
      if (*pfmt == *ptr) {
        pfmt++;
        ptr++;
      } else {
        break;
      }
    }
  }

  va_end(ap);
  return matched;
}