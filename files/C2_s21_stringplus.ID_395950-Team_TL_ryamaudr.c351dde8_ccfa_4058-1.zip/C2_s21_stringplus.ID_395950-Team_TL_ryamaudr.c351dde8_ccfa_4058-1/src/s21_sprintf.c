#include "s21_string.h"

// проверка на цифру
static int ch_is_digit(char c) { return (c >= '0' && c <= '9'); }

// вычисление длины строки
static int my_strlen(const char *str) {
  int count = 0;
  while (str && str[count] != '\0') {
    count++;
  }
  return count;
}

// перевод строки цифр в число
static int my_atoi(const char **src) {
  int num = 0;
  while (ch_is_digit(**src)) {
    num = num * 10 + (*(*src)++ - '0');
  }
  return num;
}

// разворот строки
static void reverse_buf(char *txt, int size) {
  for (int j = 0; j < size / 2; j++) {
    char tmp = txt[j];
    txt[j] = txt[size - j - 1];
    txt[size - j - 1] = tmp;
  }
}

// перевод целого числа в строку
static int utoa_custom(unsigned long long value, char *res, int base,
                       int upper) {
  int pos = 0;
  if (value == 0) {
    res[pos++] = '0';
  } else {
    while (value > 0) {
      int d = value % base;
      res[pos++] = (d < 10) ? ('0' + d) : ((upper ? 'A' : 'a') + d - 10);
      value /= base;
    }
  }
  reverse_buf(res, pos);
  res[pos] = '\0';
  return pos;
}

// перевод double в строку с фикс. точкой
static int ftoa_custom(double val, char *buf, int prec) {
  int len = 0;
  if (val < 0) {
    buf[len++] = '-';
    val = -val;
  }
  long long ipart = (long long)val;
  double frac = val - ipart;
  len += utoa_custom(ipart, buf + len, 10, 0);
  buf[len++] = '.';
  for (int i = 0; i < prec; i++) {
    frac *= 10;
    int d = (int)frac;
    buf[len++] = '0' + d;
    frac -= d;
  }
  buf[len] = '\0';
  return len;
}

// перевод double в экспоненциальный формат
static int etoa_custom(double val, char *buf, int prec, int upper) {
  int len = 0;
  if (val < 0) {
    buf[len++] = '-';
    val = -val;
  }
  int exp = 0;
  while (val >= 10.0) {
    val /= 10.0;
    exp++;
  }
  while (val > 0 && val < 1.0) {
    val *= 10.0;
    exp--;
  }
  len += ftoa_custom(val, buf + len, prec);
  buf[len++] = upper ? 'E' : 'e';
  buf[len++] = (exp >= 0) ? '+' : '-';
  if (exp < 0) exp = -exp;
  if (exp < 10) buf[len++] = '0';
  len += utoa_custom(exp, buf + len, 10, 0);
  buf[len] = '\0';
  return len;
}

// формат %g
static int gtoa_custom(double val, char *buf, int prec) {
  if (val >= 1e6 || (val != 0.0 && val < 1e-4)) {
    return etoa_custom(val, buf, prec ? prec - 1 : 5, 0);
  } else {
    int size = ftoa_custom(val, buf, prec ? prec : 6);
    int dot_index = -1;
    for (int k = 0; k < size; k++) {
      if (buf[k] == '.') dot_index = k;
    }
    if (dot_index >= 0) {
      int end = size - 1;
      while (end > dot_index && buf[end] == '0') end--;
      if (buf[end] == '.') end--;
      buf[end + 1] = '\0';
      size = end + 1;
    }
    return size;
  }
}

// реализация sprintf
int s21_sprintf(char *dest, const char *format, ...) {
  va_list args;
  va_start(args, format);
  char *cur = dest;

  while (*format) {
    if (*format != '%') {
      *cur++ = *format++;
      continue;
    }

    format++;  // пропускаем %

    int width = 0, prec = -1;
    int left_align = 0, force_sign = 0, pad_zero = 0;

    if (*format == '-') {
      left_align = 1;
      format++;
    }
    if (*format == '+') {
      force_sign = 1;
      format++;
    }
    if (*format == '0') {
      pad_zero = 1;
      format++;
    }

    if (ch_is_digit(*format)) width = my_atoi(&format);
    if (*format == '.') {
      format++;
      prec = ch_is_digit(*format) ? my_atoi(&format) : 0;
    }
    int long_mod = 0;
    if (*format == 'l') {
      long_mod = 1;
      format++;
    }

    char spec = *format++;
    char buf[256] = {0};
    int size = 0;
    char sign = 0;

    switch (spec) {
      case '%':
        *cur++ = '%';
        continue;
      case 'd':
      case 'i': {
        long long num = long_mod ? va_arg(args, long) : va_arg(args, int);
        if (num < 0) {
          sign = '-';
          num = -num;
        } else if (force_sign)
          sign = '+';
        size = utoa_custom(num, buf, 10, 0);
        break;
      }
      case 'u':
        size = utoa_custom(
            long_mod ? va_arg(args, unsigned long) : va_arg(args, unsigned int),
            buf, 10, 0);
        break;
      case 'x':
      case 'X':
        size = utoa_custom(
            long_mod ? va_arg(args, unsigned long) : va_arg(args, unsigned int),
            buf, 16, spec == 'X');
        break;
      case 'o':
        size = utoa_custom(
            long_mod ? va_arg(args, unsigned long) : va_arg(args, unsigned int),
            buf, 8, 0);
        break;
      case 'c':
        *cur++ = (char)va_arg(args, int);
        continue;
      case 's': {
        const char *txt = va_arg(args, const char *);
        size = my_strlen(txt);
        for (int j = 0; j < size; j++) *cur++ = txt[j];
        continue;
      }
      case 'p': {
        uintptr_t addr = (uintptr_t)va_arg(args, void *);
        buf[0] = '0';
        buf[1] = 'x';
        utoa_custom(addr, buf + 2, 16, 0);
        size = my_strlen(buf);
        break;
      }
      case 'f':
        size = ftoa_custom(va_arg(args, double), buf, prec >= 0 ? prec : 6);
        break;
      case 'e':
      case 'E':
        size = etoa_custom(va_arg(args, double), buf, prec >= 0 ? prec : 6,
                           spec == 'E');
        break;
      case 'g':
      case 'G':
        size = gtoa_custom(va_arg(args, double), buf, prec >= 0 ? prec : 6);
        break;
      case 'n': {
        int *pos_ptr = va_arg(args, int *);
        *pos_ptr = cur - dest;
        continue;
      }
    }

    if (sign) {
      for (int j = size; j > 0; j--) buf[j] = buf[j - 1];
      buf[0] = sign;
      size++;
    }

    int padding = width - size;
    if (!left_align)
      while (padding-- > 0) *cur++ = pad_zero ? '0' : ' ';
    for (int j = 0; j < size; j++) *cur++ = buf[j];
    if (left_align)
      while (padding-- > 0) *cur++ = ' ';
  }

  *cur = '\0';
  va_end(args);
  return cur - dest;
}
