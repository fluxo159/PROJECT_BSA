#include <stdlib.h>

#define S21_NULL ((void *)0)
typedef unsigned long s21_size_t;

static s21_size_t s21_strlen(const char *s) {
  s21_size_t length = 0;
  if (s) {
    while (s[length]) length++;
  }
  return length;
}

static const char *s21_strchr(const char *txt, int ch) {
  while (*txt) {
    if (*txt == ch) return txt;
    txt++;
  }
  return S21_NULL;
}

// s21_to_upper
void *s21_to_upper(const char *src) {
  if (!src) return S21_NULL;
  s21_size_t length = s21_strlen(src);
  char *copy = (char *)malloc(length + 1);
  if (!copy) return S21_NULL;
  for (s21_size_t pos = 0; !(pos > length); pos++) {
    char sym = src[pos];
    if (sym >= 'a' && sym <= 'z')
      copy[pos] = sym - ('a' - 'A');
    else
      copy[pos] = sym;
  }
  return copy;
}

// s21_to_lower
void *s21_to_lower(const char *src) {
  if (!src) return S21_NULL;
  s21_size_t length = s21_strlen(src);
  char *copy = (char *)malloc(length + 1);
  if (!copy) return S21_NULL;
  for (s21_size_t pos = 0; pos <= length; pos++) {
    char sym = src[pos];
    copy[pos] = (sym >= 'A' && sym <= 'Z') ? (sym + 32) : sym;
  }
  return copy;
}

// s21_insert
void *s21_insert(const char *origin, const char *extra, s21_size_t position) {
  if (!origin || !extra || position > s21_strlen(origin)) return S21_NULL;
  s21_size_t len_o = s21_strlen(origin);
  s21_size_t len_e = s21_strlen(extra);
  char *res = (char *)malloc(len_o + len_e + 1);
  if (!res) return S21_NULL;

  for (s21_size_t i = 0; i < position; i++) res[i] = origin[i];
  for (s21_size_t j = 0; j < len_e; j++) res[position + j] = extra[j];
  for (s21_size_t k = position; k <= len_o; k++) res[len_e + k] = origin[k];

  return res;
}

// s21_trim
void *s21_trim(const char *text, const char *cutset) {
  if (!text) return S21_NULL;
  if (!cutset) cutset = " \t\n\r\f\v";

  s21_size_t left = 0;
  s21_size_t right = s21_strlen(text);

  while (text[left] && s21_strchr(cutset, text[left])) left++;
  while (right > left && s21_strchr(cutset, text[right - 1])) right--;

  s21_size_t new_len = right - left;
  char *cleaned = (char *)malloc(new_len + 1);
  if (!cleaned) return S21_NULL;

  for (s21_size_t i = 0; i < new_len; i++) {
    cleaned[i] = text[left + i];
  }
  cleaned[new_len] = '\0';

  return cleaned;
}
