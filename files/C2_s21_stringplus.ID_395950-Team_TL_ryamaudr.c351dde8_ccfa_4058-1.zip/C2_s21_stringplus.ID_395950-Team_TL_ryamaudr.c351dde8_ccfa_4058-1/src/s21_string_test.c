#include "s21_string.h"

#include <check.h>

// STRLEN
START_TEST(strlen_normal) {
  char str[] = "Привет";
  ck_assert_int_eq(s21_strlen(str), strlen(str));
}
END_TEST
START_TEST(strlen_empty) {
  char str[] = "";
  ck_assert_int_eq(s21_strlen(str), strlen(str));
}
END_TEST
START_TEST(strlen_null) { ck_assert_int_eq(s21_strlen(S21_NULL), 0); }
END_TEST

// STRCHR
START_TEST(strchr_found) {
  char str[] = "Hello";
  ck_assert_ptr_eq(s21_strchr(str, 'o'), strchr(str, 'o'));
}
END_TEST
START_TEST(strchr_not) {
  char str[] = "Hello";
  ck_assert_ptr_eq(s21_strchr(str, 'x'), strchr(str, 'x'));
}
END_TEST
START_TEST(strchr_nullterm) {
  char str[] = "Hello";
  ck_assert_ptr_eq(s21_strchr(str, '\0'), strchr(str, '\0'));
}
END_TEST

// STRRCHR
START_TEST(strrchr_found) {
  char str[] = "Hello";
  ck_assert_ptr_eq(s21_strrchr(str, 'l'), strrchr(str, 'l'));
}
END_TEST
START_TEST(strrchr_not) {
  char str[] = "Hello";
  ck_assert_ptr_eq(s21_strrchr(str, 'x'), strrchr(str, 'x'));
}
END_TEST

// STRNCMP
START_TEST(strncmp_eq) {
  char a[] = "Hi", b[] = "Hi";
  ck_assert_int_eq(s21_strncmp(a, b, 2), strncmp(a, b, 2));
}
END_TEST
START_TEST(strncmp_diff) {
  char a[] = "Hi", b[] = "Ho";
  int r1 = s21_strncmp(a, b, 2), r2 = strncmp(a, b, 2);
  ck_assert_int_eq((r1 > 0), (r2 > 0));
  ck_assert_int_eq((r1 < 0), (r2 < 0));
}
END_TEST

// STRNCPY
START_TEST(strncpy_norm) {
  char src[] = "Hi", d1[5], d2[5];
  s21_strncpy(d1, src, 3);
  strncpy(d2, src, 3);
  ck_assert_str_eq(d1, d2);
}
END_TEST
START_TEST(strncpy_part) {
  char src[] = "Hello", d1[10] = {0}, d2[10] = {0};
  s21_strncpy(d1, src, 3);
  strncpy(d2, src, 3);
  ck_assert_mem_eq(d1, d2, 10);
}
END_TEST

// STRNCAT
START_TEST(strncat_norm) {
  char d1[20] = "Hi ", d2[20] = "Hi ", s[] = "there";
  s21_strncat(d1, s, 10);
  strncat(d2, s, 10);
  ck_assert_str_eq(d1, d2);
}
END_TEST
START_TEST(strncat_part) {
  char d1[20] = "Hi ", d2[20] = "Hi ", s[] = "there";
  s21_strncat(d1, s, 3);
  strncat(d2, s, 3);
  ck_assert_str_eq(d1, d2);
}
END_TEST

// MEMCHR/MEMCMP/MEMCPY/MEMSET
START_TEST(memchr_f) {
  char s[] = "Hello";
  ck_assert_ptr_eq(s21_memchr(s, 'l', 5), memchr(s, 'l', 5));
}
END_TEST
START_TEST(memchr_nf) {
  char s[] = "Hello";
  ck_assert_ptr_eq(s21_memchr(s, 'x', 5), memchr(s, 'x', 5));
}
END_TEST
START_TEST(memcmp_eq) {
  char a[] = "Hi", b[] = "Hi";
  ck_assert_int_eq(s21_memcmp(a, b, 2), memcmp(a, b, 2));
}
END_TEST
START_TEST(memcmp_diff) {
  char a[] = "Hi", b[] = "Ho";
  int r1 = s21_memcmp(a, b, 2), r2 = memcmp(a, b, 2);
  ck_assert_int_eq((r1 > 0), (r2 > 0));
  ck_assert_int_eq((r1 < 0), (r2 < 0));
}
END_TEST
START_TEST(memcpy_n) {
  char s[] = "Hi", d1[5], d2[5];
  s21_memcpy(d1, s, 3);
  memcpy(d2, s, 3);
  ck_assert_mem_eq(d1, d2, 3);
}
END_TEST
START_TEST(memset_n) {
  char d1[5], d2[5];
  s21_memset(d1, 'A', 5);
  memset(d2, 'A', 5);
  ck_assert_mem_eq(d1, d2, 5);
}
END_TEST

// STRCSPN/STRPBRK/STRSTR
START_TEST(strcspn_n) {
  char a[] = "Hello", b[] = "aeiou";
  ck_assert_int_eq(s21_strcspn(a, b), strcspn(a, b));
}
END_TEST
START_TEST(strcspn_nomatch) {
  char a[] = "bcdfg", b[] = "xyz";
  ck_assert_int_eq(s21_strcspn(a, b), strcspn(a, b));
}
END_TEST
START_TEST(strpbrk_f) {
  char a[] = "Hello", b[] = "aeiou";
  ck_assert_ptr_eq(s21_strpbrk(a, b), strpbrk(a, b));
}
END_TEST
START_TEST(strpbrk_nf) {
  char a[] = "bcdfg", b[] = "xyz";
  ck_assert_ptr_eq(s21_strpbrk(a, b), strpbrk(a, b));
}
END_TEST
START_TEST(strstr_f) {
  char h[] = "Hello World", n[] = "World";
  ck_assert_ptr_eq(s21_strstr(h, n), strstr(h, n));
}
END_TEST
START_TEST(strstr_nf) {
  char h[] = "Hello", n[] = "xyz";
  ck_assert_ptr_eq(s21_strstr(h, n), strstr(h, n));
}
END_TEST
START_TEST(strstr_empty) {
  char h[] = "Hello", n[] = "";
  ck_assert_ptr_eq(s21_strstr(h, n), strstr(h, n));
}
END_TEST

// STRTOK
START_TEST(strtok_norm) {
  char s1[] = "a,b,c", s2[] = "a,b,c", d[] = ",";
  char *t1 = s21_strtok(s1, d), *t2 = strtok(s2, d);
  while (t1 && t2) {
    ck_assert_str_eq(t1, t2);
    t1 = s21_strtok(S21_NULL, d);
    t2 = strtok(NULL, d);
  }
  ck_assert_ptr_eq(t1, t2);
}
END_TEST

// SPRINTF
START_TEST(sprintf_char) {
  char b1[50], b2[50];
  int r1 = s21_sprintf(b1, "%c", 'A'), r2 = sprintf(b2, "%c", 'A');
  ck_assert_str_eq(b1, b2);
  ck_assert_int_eq(r1, r2);
}
END_TEST
START_TEST(sprintf_str) {
  char b1[50], b2[50];
  int r1 = s21_sprintf(b1, "%s", "Hi"), r2 = sprintf(b2, "%s", "Hi");
  ck_assert_str_eq(b1, b2);
  ck_assert_int_eq(r1, r2);
}
END_TEST
START_TEST(sprintf_int) {
  char b1[50], b2[50];
  int r1 = s21_sprintf(b1, "%d", 42), r2 = sprintf(b2, "%d", 42);
  ck_assert_str_eq(b1, b2);
  ck_assert_int_eq(r1, r2);
}
END_TEST
START_TEST(sprintf_float) {
  char b1[50], b2[50];
  int r1 = s21_sprintf(b1, "%.2f", 3.14), r2 = sprintf(b2, "%.2f", 3.14);
  ck_assert_str_eq(b1, b2);
  ck_assert_int_eq(r1, r2);
}
END_TEST

// STRERROR
START_TEST(strerror_val) {
  for (int i = 0; i < 3; i++) {
    char *r = s21_strerror(i);
    ck_assert_ptr_ne(r, S21_NULL);
    ck_assert_int_gt(s21_strlen(r), 0);
  }
}
END_TEST
START_TEST(strerror_inv) {
  char *r = s21_strerror(9999);
  ck_assert_ptr_ne(r, S21_NULL);
  ck_assert_ptr_ne(s21_strstr(r, "Неизвестная"), S21_NULL);
}
END_TEST

Suite *s21_suite(void) {
  Suite *s = suite_create("s21_string");
  TCase *tc;
#define ADD(name, ...)      \
  tc = tcase_create(#name); \
  __VA_ARGS__ suite_add_tcase(s, tc);
  ADD(strlen, tcase_add_test(tc, strlen_normal);
      tcase_add_test(tc, strlen_empty); tcase_add_test(tc, strlen_null);)
  ADD(strchr, tcase_add_test(tc, strchr_found); tcase_add_test(tc, strchr_not);
      tcase_add_test(tc, strchr_nullterm);)
  ADD(strrchr, tcase_add_test(tc, strrchr_found);
      tcase_add_test(tc, strrchr_not);)
  ADD(strncmp, tcase_add_test(tc, strncmp_eq);
      tcase_add_test(tc, strncmp_diff);)
  ADD(strncpy, tcase_add_test(tc, strncpy_norm);
      tcase_add_test(tc, strncpy_part);)
  ADD(strncat, tcase_add_test(tc, strncat_norm);
      tcase_add_test(tc, strncat_part);)
  ADD(memchr, tcase_add_test(tc, memchr_f); tcase_add_test(tc, memchr_nf);)
  ADD(memcmp, tcase_add_test(tc, memcmp_eq); tcase_add_test(tc, memcmp_diff);)
  ADD(memcpy, tcase_add_test(tc, memcpy_n);)
  ADD(memset, tcase_add_test(tc, memset_n);)
  ADD(strcspn, tcase_add_test(tc, strcspn_n);
      tcase_add_test(tc, strcspn_nomatch);)
  ADD(strpbrk, tcase_add_test(tc, strpbrk_f); tcase_add_test(tc, strpbrk_nf);)
  ADD(strstr, tcase_add_test(tc, strstr_f); tcase_add_test(tc, strstr_nf);
      tcase_add_test(tc, strstr_empty);)
  ADD(strtok, tcase_add_test(tc, strtok_norm);)
  ADD(sprintf, tcase_add_test(tc, sprintf_char);
      tcase_add_test(tc, sprintf_str); tcase_add_test(tc, sprintf_int);
      tcase_add_test(tc, sprintf_float);)
  ADD(strerror, tcase_add_test(tc, strerror_val);
      tcase_add_test(tc, strerror_inv);)
  return s;
}

int main(void) {
  SRunner *sr = srunner_create(s21_suite());
  printf("Запуск тестов s21_string...\n");
  srunner_run_all(sr, CK_NORMAL);
  int failed = srunner_ntests_failed(sr);
  srunner_free(sr);
  printf(failed == 0 ? "\nВсе тесты пройдены!\n" : "\nОшибок: %d\n", failed);
  return failed == 0 ? EXIT_SUCCESS : EXIT_FAILURE;
}
