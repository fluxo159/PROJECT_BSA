#include "s21_string.h"
// MEMORY UTILS

void *s21_memchr(const void *str, int c, s21_size_t n) {
  const unsigned char *cur = (const unsigned char *)str;
  for (s21_size_t k = 0; k < n; k++) {
    if (cur[k] == (unsigned char)c) {
      return (void *)(cur + k);
    }
  }
  return S21_NULL;
}

int s21_memcmp(const void *str1, const void *str2, s21_size_t n) {
  const unsigned char *p1 = str1;
  const unsigned char *p2 = str2;
  for (s21_size_t k = 0; k < n; k++) {
    if (p1[k] != p2[k]) {
      return (int)(p1[k] - p2[k]);
    }
  }
  return 0;
}

void *s21_memcpy(void *dest, const void *src, s21_size_t n) {
  if (!dest || !src) return dest;
  unsigned char *d = (unsigned char *)dest;
  const unsigned char *s = (const unsigned char *)src;
  for (s21_size_t k = 0; k < n; k++) {
    d[k] = s[k];
  }
  return dest;
}

void *s21_memset(void *str, int c, s21_size_t n) {
  if (!str) return str;
  unsigned char *cur = (unsigned char *)str;
  for (s21_size_t k = 0; k < n; k++) {
    cur[k] = (unsigned char)c;
  }
  return str;
}

// STRING UTILS

s21_size_t s21_strlen(const char *str) {
  s21_size_t res = 0;
  if (str) {
    while (str[res]) res++;
  }
  return res;
}

char *s21_strchr(const char *str, int c) {
  if (!str) return S21_NULL;
  do {
    if (*str == (char)c) return (char *)str;
  } while (*str++);
  return S21_NULL;
}

int s21_strncmp(const char *s1, const char *s2, s21_size_t n) {
  if (!s1 || !s2) return 0;
  for (s21_size_t k = 0; k < n; k++) {
    if (s1[k] != s2[k] || !s1[k] || !s2[k]) {
      return (unsigned char)s1[k] - (unsigned char)s2[k];
    }
  }
  return 0;
}

char *s21_strcpy(char *dest, const char *src) {
  if (!dest || !src) return dest;
  char *out = dest;
  while ((*out++ = *src++));
  return dest;
}

char *s21_strncpy(char *dest, const char *src, s21_size_t n) {
  if (!dest || !src) return dest;
  s21_size_t i = 0;
  while (i < n && src[i]) {
    dest[i] = src[i];
    i++;
  }
  while (i < n) dest[i++] = '\0';
  return dest;
}

char *s21_strncat(char *dest, const char *src, s21_size_t n) {
  if (!dest || !src) return dest;
  s21_size_t d_len = s21_strlen(dest);
  s21_size_t k = 0;
  while (k < n && src[k]) {
    dest[d_len + k] = src[k];
    k++;
  }
  dest[d_len + k] = '\0';
  return dest;
}

s21_size_t s21_strcspn(const char *s1, const char *s2) {
  if (!s1 || !s2) return 0;
  s21_size_t cnt = 0;
  while (s1[cnt]) {
    for (const char *p = s2; *p; p++) {
      if (s1[cnt] == *p) return cnt;
    }
    cnt++;
  }
  return cnt;
}

// STRERROR

char *s21_strerror(int errnum) {
  static char buf[50];
  if (errnum >= 0 && errnum < S21_ERRLIST_SIZE) {
    return (char *)s21_errlist[errnum];
  }

  const char *prefix = "Неизвестная ошибка ";
  char *p = buf;
  while (*prefix) *p++ = *prefix++;

  if (errnum < 0) {
    *p++ = '-';
    errnum = -errnum;
  }

  char tmp[20];
  int idx = 0;
  do {
    tmp[idx++] = '0' + (errnum % 10);
    errnum /= 10;
  } while (errnum);

  while (idx--) *p++ = tmp[idx];
  *p = '\0';

  return buf;
}
