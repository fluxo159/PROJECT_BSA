#include "s21_string.h"
char *s21_strpbrk(const char *s1, const char *s2) {
  if (!s1 || !s2) return S21_NULL;
  for (; *s1; s1++) {
    for (const char *p = s2; *p; p++) {
      if (*s1 == *p) return (char *)s1;
    }
  }
  return S21_NULL;
}

char *s21_strrchr(const char *str, int c) {
  if (!str) return S21_NULL;
  char *res = S21_NULL;
  do {
    if (*str == (char)c) res = (char *)str;
  } while (*str++);
  return res;
}

char *s21_strstr(const char *haystack, const char *needle) {
  if (!haystack || !needle) return S21_NULL;
  if (!*needle) return (char *)haystack;
  for (; *haystack; haystack++) {
    const char *h = haystack;
    const char *n = needle;
    while (*h && *n && *h == *n) {
      h++;
      n++;
    }
    if (!*n) return (char *)haystack;
  }
  return S21_NULL;
}

char *s21_strtok(char *str, const char *delim) {
  static char *save;
  if (str) save = str;
  if (!save || !delim) return S21_NULL;

  while (*save && s21_strchr(delim, *save)) save++;
  if (!*save) return S21_NULL;

  char *start = save;
  while (*save && !s21_strchr(delim, *save)) save++;
  if (*save) *save++ = '\0';

  return start;
}
