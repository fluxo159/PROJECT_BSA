#ifndef S21_STRING_H
#define S21_STRING_H

#include <ctype.h>   // функции для проверки and преобразования символов
#include <stdarg.h>  // работа с переменным числом аргументов
#include <stddef.h>  // базовые служебные типы (size_t and NULL)
#include <stdint.h>  // фиксированные целочисленные типы
#include <stdio.h>
#include <stdlib.h>  // память, преобразования, случайные числа
// Собственный тип для размеров
typedef unsigned long s21_size_t;

// Переопределённый NULL
#define S21_NULL ((void *)0)
// СПЕЦИФИКАТОРЫ ДЛЯ ФОРМАТИРОВАНИЯ
typedef struct {
  int minus;          // Флаг '-'
  int plus;           // Флаг '+'
  int space;          // Флаг ' '
  int hash;           // Флаг '#'
  int zero;           // Флаг '0'
  int width;          // Минимальная ширина
  int precision;      // Точность
  int has_precision;  // Указана ли точность
  char length;        // Модификатор длины (h/l/L)
  char specifier;     // Спецификатор (d, s, f и т.д.)
} fmt_spec_t;

typedef struct {
  int width;       // Максимальная ширина поля
  int suppress;    // Флаг *
  char length;     // h/l/L
  char specifier;  // d, s, f и т.д
} scan_spec_t;

// СПИСКИ СООБЩЕНИЙ ОБ ОШИБКАХ

#ifdef __linux__
#define S21_ERRLIST_SIZE 134
static const char *s21_errlist[]
    __attribute__((unused)) = {"Успех",
                               "Операция не разрешена",
                               "Нет такого файла или каталога",
                               "Нет такого процесса",
                               "Прерванный системный вызов",
                               "Ошибка ввода-вывода",
                               "Нет такого устройства или адреса",
                               "Слишком длинный список аргументов",
                               "Неверный формат исполняемого файла",
                               "Неверный номер файла",
                               "Нет дочерних процессов",
                               "Попробуйте еще раз",
                               "Недостаточно памяти",
                               "Доступ запрещен",
                               "Неверный адрес",
                               "Требуется блочное устройство",
                               "Ресурс занят",
                               "Файл существует",
                               "Связь между устройствами",
                               "Нет такого устройства",
                               "Не каталог",
                               "Это каталог",
                               "Неверный аргумент",
                               "Переполнение таблицы файлов",
                               "Слишком много открытых файлов",
                               "Не пишущая машинка",
                               "Текстовый файл занят",
                               "Файл слишком большой",
                               "Нет места на устройстве",
                               "Недопустимый поиск",
                               "ФС только для чтения",
                               "Слишком много ссылок",
                               "Обрыв канала",
                               "Аргумент вне области определения",
                               "Математический результат не представим"};
#elif __APPLE__
#define S21_ERRLIST_SIZE 107
static const char *s21_errlist[]
    __attribute__((unused)) = {"Неопределенная ошибка: 0",
                               "Операция не разрешена",
                               "Нет такого файла или каталога",
                               "Нет такого процесса",
                               "Прерванный системный вызов",
                               "Ошибка ввода/вывода",
                               "Устройство не настроено",
                               "Слишком длинный список аргументов",
                               "Неверный формат исполняемого файла",
                               "Неверный дескриптор",
                               "Нет дочерних процессов",
                               "Взаимная блокировка предотвращена",
                               "Не удалось выделить память",
                               "Доступ запрещен",
                               "Неверный адрес",
                               "Требуется блочное устройство",
                               "Ресурс занят",
                               "Файл существует",
                               "Связь между устройствами",
                               "Операция не поддерживается устройством",
                               "Не каталог",
                               "Это каталог",
                               "Неверный аргумент",
                               "Слишком много открытых файлов в системе",
                               "Слишком много открытых файлов",
                               "Неподходящий ioctl",
                               "Текстовый файл занят",
                               "Файл слишком большой",
                               "Нет места на устройстве",
                               "Недопустимый поиск",
                               "ФС только для чтения",
                               "Слишком много ссылок",
                               "Обрыв канала",
                               "Числовой аргумент вне области",
                               "Результат слишком большой"};
#endif

// Работа с памятью
void *s21_memchr(const void *s, int c, s21_size_t n);
int s21_memcmp(const void *s1, const void *s2, s21_size_t n);
void *s21_memcpy(void *dst, const void *src, s21_size_t n);
void *s21_memset(void *s, int c, s21_size_t n);

// Работа со строками
char *s21_strncat(char *dst, const char *src, s21_size_t n);
char *s21_strchr(const char *s, int c);
char *s21_strcpy(char *dst, const char *src);
int s21_strncmp(const char *s1, const char *s2, s21_size_t n);
char *s21_strncpy(char *dst, const char *src, s21_size_t n);
s21_size_t s21_strcspn(const char *s, const char *rej);
char *s21_strerror(int err_code);
s21_size_t s21_strlen(const char *s);
char *s21_strpbrk(const char *s, const char *mask);
char *s21_strrchr(const char *s, int c);
char *s21_strstr(const char *hay, const char *needle);
char *s21_strtok(char *s, const char *delim);
// sprintf and sscanf

int s21_sprintf(char *buf, const char *format, ...);
int s21_sprintf_extended(char *buf, const char *format, ...);
int s21_sscanf(const char *s, const char *format, ...);

void *s21_to_upper(const char *s);
void *s21_to_lower(const char *s);
void *s21_insert(const char *src, const char *add, s21_size_t pos);
void *s21_trim(const char *src, const char *cutset);

#endif
