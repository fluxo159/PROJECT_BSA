#include <check.h>
#include <math.h>

#include "s21_string.h"

// sscanf
START_TEST(sscanf_int) {
  int r1, r2, v1, v2;
  r1 = s21_sscanf("123", "%d", &v1);
  r2 = sscanf("123", "%d", &v2);
  ck_assert_int_eq(r1, r2);
  ck_assert_int_eq(v1, v2);
}
END_TEST
START_TEST(sscanf_neg) {
  int r1, r2, v1, v2;
  r1 = s21_sscanf("-456", "%d", &v1);
  r2 = sscanf("-456", "%d", &v2);
  ck_assert_int_eq(r1, r2);
  ck_assert_int_eq(v1, v2);
}
END_TEST
START_TEST(sscanf_u) {
  int r1, r2;
  unsigned int v1, v2;
  r1 = s21_sscanf("123", "%u", &v1);
  r2 = sscanf("123", "%u", &v2);
  ck_assert_int_eq(r1, r2);
  ck_assert_uint_eq(v1, v2);
}
END_TEST
START_TEST(sscanf_hex) {
  int r1, r2;
  unsigned int v1, v2;
  r1 = s21_sscanf("1a2b", "%x", &v1);
  r2 = sscanf("1a2b", "%x", &v2);
  ck_assert_int_eq(r1, r2);
  ck_assert_uint_eq(v1, v2);
}
END_TEST
START_TEST(sscanf_octal) {
  int r1, r2;
  unsigned int v1, v2;
  r1 = s21_sscanf("123", "%o", &v1);
  r2 = sscanf("123", "%o", &v2);
  ck_assert_int_eq(r1, r2);
  ck_assert_uint_eq(v1, v2);
}
END_TEST
START_TEST(sscanf_float) {
  int r1, r2;
  float v1, v2;
  r1 = s21_sscanf("3.14", "%f", &v1);
  r2 = sscanf("3.14", "%f", &v2);
  ck_assert_int_eq(r1, r2);
  ck_assert_float_eq_tol(v1, v2, 0.001);
}
END_TEST
START_TEST(sscanf_multi) {
  int r1, r2, i1, i2;
  float f1, f2;
  char s1[100], s2[100];
  r1 = s21_sscanf("42 3.14 test", "%d %f %s", &i1, &f1, s1);
  r2 = sscanf("42 3.14 test", "%d %f %s", &i2, &f2, s2);
  ck_assert_int_eq(r1, r2);
  ck_assert_int_eq(i1, i2);
  ck_assert_float_eq_tol(f1, f2, 0.001);
  ck_assert_str_eq(s1, s2);
}
END_TEST
START_TEST(sscanf_ptr_null) {
  void *p = (void *)0x1234;
  int r = s21_sscanf("xyz", "%p", &p);
  ck_assert_int_eq(r, 0);
}

START_TEST(sscanf_float_only_dot) {
  float f = 0;
  int r = s21_sscanf(".25", "%f", &f);
  ck_assert_int_eq(r, 1);
  ck_assert_float_eq_tol(f, 0.25, 1e-6);
}

START_TEST(sscanf_percent_n) {
  int pos = -1;
  int val = 123;
  int r = s21_sscanf("123", "%d%n", &val, &pos);
  ck_assert_int_eq(r, 1);
  ck_assert_int_eq(pos, 3);
}

START_TEST(sscanf_suppress_int) {
  int val = -1;
  int r = s21_sscanf("100", "%*d %d", &val);  // second value missing
  ck_assert_int_eq(r, 0);
}

// sprintf
START_TEST(sprintf_hex) {
  char b1[100], b2[100];
  int r1 = s21_sprintf(b1, "Hex: %x", 255);
  int r2 = sprintf(b2, "Hex: %x", 255);
  ck_assert_str_eq(b1, b2);
  ck_assert_int_eq(r1, r2);
}
END_TEST
START_TEST(sprintf_oct) {
  char b1[100], b2[100];
  int r1 = s21_sprintf(b1, "Oct: %o", 64);
  int r2 = sprintf(b2, "Oct: %o", 64);
  ck_assert_str_eq(b1, b2);
  ck_assert_int_eq(r1, r2);
}
END_TEST
START_TEST(sprintf_sci) {
  char b1[100], b2[100];
  int r1 = s21_sprintf(b1, "%e", 1234.5);
  int r2 = sprintf(b2, "%e", 1234.5);
  ck_assert_str_eq(b1, b2);
  ck_assert_int_eq(r1, r2);
}
END_TEST
START_TEST(sprintf_g) {
  char b1[100], b2[100];
  int r1 = s21_sprintf(b1, "%g", 1234.5);
  int r2 = sprintf(b2, "%g", 1234.5);
  ck_assert_str_eq(b1, b2);
  ck_assert_int_eq(r1, r2);
}
END_TEST
START_TEST(sprintf_p) {
  char b1[100], b2[100];
  int x = 1;
  int r1 = s21_sprintf(b1, "%p", &x);
  int r2 = sprintf(b2, "%p", &x);
  ck_assert_str_eq(b1, b2);
  ck_assert_int_eq(r1, r2);
}
END_TEST

// bonus
START_TEST(to_upper) {
  char *r = s21_to_upper("abc");
  ck_assert_str_eq(r, "ABC");
  free(r);
}
END_TEST
START_TEST(to_lower) {
  char *r = s21_to_lower("ABC");
  ck_assert_str_eq(r, "abc");
  free(r);
}
END_TEST
START_TEST(insert_test) {
  char *r = s21_insert("Hello", "World ", 0);
  ck_assert_str_eq(r, "World Hello");
  free(r);
}
END_TEST
START_TEST(trim_test) {
  char *r = s21_trim("   abc   ", " ");
  ck_assert_str_eq(r, "abc");
  free(r);
}
END_TEST

Suite *s21_comprehensive_suite(void) {
  Suite *s = suite_create("s21_string");
  TCase *tc;

  tc = tcase_create("sscanf");
  tcase_add_test(tc, sscanf_int);
  tcase_add_test(tc, sscanf_neg);
  tcase_add_test(tc, sscanf_u);
  tcase_add_test(tc, sscanf_hex);
  tcase_add_test(tc, sscanf_octal);
  tcase_add_test(tc, sscanf_float);
  tcase_add_test(tc, sscanf_multi);
  tcase_add_test(tc, sscanf_ptr_null);
  tcase_add_test(tc, sscanf_float_only_dot);
  tcase_add_test(tc, sscanf_percent_n);
  tcase_add_test(tc, sscanf_suppress_int);
  suite_add_tcase(s, tc);

  tc = tcase_create("sprintf");
  tcase_add_test(tc, sprintf_hex);
  tcase_add_test(tc, sprintf_oct);
  tcase_add_test(tc, sprintf_sci);
  tcase_add_test(tc, sprintf_g);
  tcase_add_test(tc, sprintf_p);
  suite_add_tcase(s, tc);

  tc = tcase_create("bonus");
  tcase_add_test(tc, to_upper);
  tcase_add_test(tc, to_lower);
  tcase_add_test(tc, insert_test);
  tcase_add_test(tc, trim_test);
  suite_add_tcase(s, tc);

  return s;
}

int main(void) {
  Suite *s = s21_comprehensive_suite();
  SRunner *sr = srunner_create(s);
  srunner_run_all(sr, CK_VERBOSE);
  int failed = srunner_ntests_failed(sr);
  srunner_free(sr);
  return (failed == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}
