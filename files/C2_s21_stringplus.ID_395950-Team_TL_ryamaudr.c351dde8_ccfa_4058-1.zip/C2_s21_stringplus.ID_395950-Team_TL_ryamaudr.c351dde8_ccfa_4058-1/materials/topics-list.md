Hello, student of School21!😉

To make it easier for you to navigate the material, we have prepared a list of topics that you will learn in this project. 

We will study: 
- strings in C language and how to work with them;
- working with dinamic memory and proper error handling;
- formatted I/O.

Now, knowing what awaits you in this project, you can slowly begin to study the topics listed above.😇